<?php
/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/24
 * Time: 上午1:29
 */

$config['protocol'] = 'smtp';
$config['charset'] = 'utf-8';
$config['smtp_host'] = "";
$config['smtp_user'] = "";
$config['smtp_pass'] = "";
$config['smtp_port'] = 25;
$config['mailtype'] = "html";