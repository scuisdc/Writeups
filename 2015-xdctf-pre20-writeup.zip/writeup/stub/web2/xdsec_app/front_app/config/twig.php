<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['extension'] = ".twig";
$config['template_dir'] = APPPATH . "views/";
$config['cache_dir'] = APPPATH . "cache/twig/";
$config['debug'] = false;
$config['auto_reload'] = true;
$config['autoescape'] = true;
/* End of file twig.php */
/* Location: ./application/config/twig.php */