<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/23
 * Time: 下午11:49
 */

$config = [
    'auth' => [
        [
            'field' => 'email',
            'label' => 'Email',
            'rules' => 'required|valid_email|is_unique[members.email]'
        ],
        [
            'field' => 'password',
            'label' => 'Password',
            'rules' => 'required|min_length[8]|matches[repassword]|callback_complex_password'
        ],
        [
            'field' => 'repassword',
            'label' => 'Password Confirmation',
            'rules' => 'required'
        ],
        [
            'field' => 'nickname',
            'label' => 'Nickname',
            'rules' => 'required|min_length[3]'
        ]
    ],
    'post' => [
        [
            'field' => 'title',
            'label' => 'Post title',
            'rules' => 'required'
        ],
        [
            'field' => 'title',
            'label' => 'Post content',
            'rule' => 'required|callback_filter_content'
        ]
    ],
    'profile' => [
        [
            'field' => 'nickname',
            'label' => 'Nickname',
            'rules' => 'required|min_length[3]'
        ]
    ]
];