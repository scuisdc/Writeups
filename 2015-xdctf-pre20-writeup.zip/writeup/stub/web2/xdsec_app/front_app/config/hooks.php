<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Hooks
| -------------------------------------------------------------------------
| This file lets you define "hooks" to extend CI without hacking the core
| files.  Please see the user guide for info:
|
|	http://codeigniter.com/user_guide/general/hooks.html
|
*/

$hook['post_controller_constructor'] = function()
{
    $self = & get_instance();
    $self->load->library('session');
    if(empty($_SESSION['userinfo'])) {
        $self->session->userinfo = [
            "uid" => 0,
            "email" => null,
            "nickname" => "Guest",
            "role" => "guest"
        ];
    }
    $self->template_data["userinfo"] = $self->session->userinfo;
    $self->template_data["is_user"] = ($self->session->userinfo["uid"] > 0);

    if(method_exists($self, "init")) {
        call_user_func([$self, "init"]);
    }
};

$hook['post_controller'] = function()
{
    session_write_close();
};