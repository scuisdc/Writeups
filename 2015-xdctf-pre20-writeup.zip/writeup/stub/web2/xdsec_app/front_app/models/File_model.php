<?php

/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/24
 * Time: 下午3:43
 */
class File_model extends Xdsec_Model
{
    private $ci;
    private $attachment_dir;
    function __construct()
    {
        CI_Model::__construct();
        $this->ci = & get_instance();
        $this->attachment_dir = $this->ci->config->item("attachment_dir");
    }

    function getFiles()
    {
        $uid = $this->ci->session->userinfo["uid"];
        $query = $this->db->get_where("files", ["uid" => $uid]);
        return $query->result_array();
    }

    function getFile($fid)
    {
        $uid = $this->ci->session->userinfo["uid"];
        $query = $this->db->get_where("files", [
            "fid" => $fid,
            "uid" => $uid
        ]);
        return $query->row();
    }

    function addFile($filename, $realname)
    {
        $uid = $this->ci->session->userinfo["uid"];
        $data = [
            "filename" => $filename,
            "realname" => $realname,
            "uid" => $uid
        ];
        return $this->db->insert("files", $data);
    }

    function deleteFiles($fid_arr)
    {
        if($this->ci->session->userinfo["role"] == "admin") {
            return false;
        }
        $uid = $this->ci->session->userinfo["uid"];
        $this->filter_number($fid_arr);
        if(empty($fid_arr)) {
            return false;
        }
        $obj = $this->db->where("uid", $uid)->where_in("fid", $fid_arr)->get("files");
        $files = $obj->result();
        $this->db->where("uid", $uid)->where_in("fid", $fid_arr)->delete("files");
        foreach($files as $file) {
            $path = realpath($this->attachment_dir . '/' . $file->realname);
            if(file_exists($path)) {
                unlink($path);
            }
        }
    }

    function getUserFileCount()
    {
        $uid = $this->ci->session->userinfo["uid"];
        return $this->db->where("uid", $uid)->count_all_results("files");
    }
}