<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/22
 * Time: 下午5:25
 */
class User_model extends Xdsec_Model
{

    function insert_user($email, $password, $nickname)
    {
        $password = password_hash($password, PASSWORD_DEFAULT);
        $data = [
            "email" => $email,
            "password" => $password,
            "nickname" => $nickname,
            "role" => "user"
        ];
        return $this->db->insert("members", $data);
    }

    function check_user_password($email, $password)
    {
        $verify = false;
        $query = $this->db->get_where("members", ["email" => $email]);
        if($query->num_rows() > 0) {
            $user = $query->row();
            if(password_verify($password, $user->password)) {
                $verify = true;
            }
        }
        return $verify;
    }

    function update_userinfo($data, $uid)
    {
        $_data = [];
        foreach(["nickname", "password", "verify", "role", "face", "motto"] as $key) {
            if(array_key_exists($key, $data)) {
                $_data[$key] = $data[$key];
            }
        }
        if(isset($_data["password"])) {
            $_data["password"] = password_hash($_data["password"], PASSWORD_DEFAULT);
        }
        $this->db->where("uid", $uid)->update("members", $_data);
    }

    function get_user($val, $key="uid")
    {
        $query = $this->db->get_where("members", [$key => $val]);
        return $query->row_array();
    }

    function nickname_unique($nickname)
    {
        $ci = & get_instance();
        if($ci->is_user() && $nickname == $this->session->userinfo["nickname"]) {
            return true;
        }
        return empty($this->get_user($nickname, "nickname"));
    }
}