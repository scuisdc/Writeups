<?php

/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/24
 * Time: 下午1:55
 */
class Post_model extends Xdsec_Model
{
    private $ci;
    function __construct()
    {
        CI_Model::__construct();
        $this->ci = & get_instance();
    }

    public function addPost($title, $content, $tags)
    {
        $uid = $this->ci->session->userinfo["uid"];
        $data = [
            "title" => $title,
            "content" => $content,
            "uid" => $uid,
            "tags" => $tags
        ];
        return $this->db->insert("posts", $data);
    }

    public function deletePost($pid_arr)
    {
        $this->filter_number($pid_arr);
        if(empty($pid_arr)) {
            return false;
        }
        return $this->db
            ->where("uid", $this->ci->session->userinfo["uid"])
            ->where_in("pid", $pid_arr)
            ->delete("posts");
    }

    public function getUserPosts($uid=null)
    {
        $uid = empty($uid) ? $this->ci->session->userinfo["uid"] : $uid;
        $query = $this->db->order_by("addtime", "desc")->get_where("posts", ["uid" => $uid]);
        return $query->result_array();
    }

    public function getUserPostCount()
    {
        $uid = $this->ci->session->userinfo["uid"];
        return $this->db->where("uid", $uid)->count_all_results("posts");
    }

    public function getPost($pid)
    {
        $query = $this->db
            ->where("pid", $pid)
            ->from("posts")
            ->join("members", "members.uid = posts.uid", "inner")
            ->get();
        return $query->row();
    }

    public function getAdminPosts()
    {
        $query = $this->db
            ->where("role", "admin")
            ->from("members")
            ->join("posts", "members.uid = posts.uid", "inner")
            ->get();
        return $query->result();
    }

    public function searchPosts($keyword)
    {
        $query = $this->db
            ->like("title", $keyword)
            ->from("members")
            ->join("posts", "members.uid = posts.uid", "inner")
            ->get();
        return $query->result();
    }
}