<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Gregwar\Captcha\CaptchaBuilder;

/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/22
 * Time: 上午1:41
 */
class Auth extends Public_Controller
{
    function __construct()
    {
        Public_Controller::__construct();
    }

    function init()
    {
        Public_Controller::init();
        $this->load->model("User_model", "user");
        $this->load->library('form_validation');
        $this->twig->addFunction('form_set_value', 'set_value');
        $this->twig->addFunction('form_validation_errors', 'validation_errors');

        $this->form_validation->set_message('is_unique', 'Your {field} has been used');
    }

    public function handle_register()
    {
        if($this->input->method() == "post") {
            $email = I("post.email");
            $password = I("post.password");
            $nickname = I("post.nickname");
            $form_data = [
                "email" => $email,
                "password" => $password,
                "repassword" => I("post.repassword"),
                "nickname" => $nickname
            ];
            $this->form_validation->set_data($form_data);
            if($this->form_validation->run('auth')) {
                $this->user->insert_user($email, $password, $nickname);
                redirect('');
            } else {
                $this->view("register.html");
            }
        } else {
            $this->view("register.html");
        }
    }

    public function handle_login()
    {
        if($this->input->method() == "post") {
            $email = I("post.email");
            $password = I("post.password");

            if($this->user->check_user_password($email, $password)) {
                $user = $this->user->get_user($email, "email");
                unset($user["password"]);
                $this->session->userinfo = $user;

                redirect();
            } else {
                $this->error("Password error!");
            }
        } else {
            $this->view("login.html");
        }
    }

    public function handle_forgetpwd()
    {
        if($this->input->method() == "post") {
            if(empty($_POST["email"])) {
                $this->error("Bad request", site_url("auth/forgetpwd"));
            }
            if(empty($_SESSION['captcha']) ||
                strtolower($this->session->captcha) != I('post.captcha', '', null, 'strtolower|trim')) {
                $this->error("Captcha code error", site_url("auth/forgetpwd"));
            } else {
                unset($_SESSION['captcha']);
            }
            $email = I("post.email");
            $user = $this->user->get_user($email, "email");
            if(empty($user)) {
                $this->error("Email doesn't exists", site_url("auth/forgetpwd"));
            }
            $verify = random_string('md5');
            $this->user->update_userinfo(["verify" => $verify], $user["uid"]);

            $this->load->library("email");
            $this->email->from("game@waf.science", "XDSEC-CMS");
            $this->email->to($user["email"]);
            $title = "[XDSEC-CMS] Find your password";
            $url = site_url("auth/resetpwd")."?email={$user['email']}&verify={$verify}";
            $content = sprintf('hi:<br/>&nbsp;&nbsp;Click here to change your password:
                <br/><a href="%s" target="_blank">%s</a>', $url, $url);
            $this->email->subject($title);
            $this->email->message($content);
            $this->email->send();
            $this->success("Confirm email has been sent", site_url());
        } else {
            $this->view("forgetpwd.html");
        }
    }

    public function handle_resetpwd()
    {
        if(empty($_GET["email"]) || empty($_GET["verify"])) {
            $this->error("Bad request", site_url("auth/forgetpwd"));
        }
        $user = $this->user->get_user(I("get.email"), "email");
        if(I('get.verify') != $user['verify']) {
            $this->error("Your verify code is error", site_url('auth/forgetpwd'));
        }
        if($this->input->method() == "post") {
            $password = I("post.password");
            if(!$this->confirm_password($password)) {
                $this->error("Confirm password error");
            }
            if(!$this->complex_password($password)) {
                $this->error("Password must have at least one alpha and one number");
            }
            if(strlen($password) < 8) {
                $this->error("The Password field must be at least 8 characters in length");
            }
            $this->user->update_userinfo([
                "password" => $password,
                "verify" => null
            ], $user["uid"]);
            $this->success("Password update successful!", site_url("auth/login"));
        } else {
            $url = site_url("auth/resetpwd") . "?email={$user['email']}&verify={$user['verify']}";
            $this->view("resetpwd.html", ["form_url" => $url]);
        }
    }

    public function handle_logout()
    {
        unset($_SESSION['userinfo']);
        redirect();
    }

    public function handle_captcha()
    {
        $this->output->set_content_type("image/jpeg");
        $builder = new CaptchaBuilder;
        $builder->build();
        $this->session->captcha = $builder->getPhrase();
        $builder->output();
    }

    public function confirm_password($password)
    {
        $this->form_validation->set_message('confirm_password', 'Confirm password error');
        return $password == I('post.repassword');
    }
}