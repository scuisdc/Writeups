<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Open extends Public_Controller
{
    function init()
    {
        Public_Controller::init();
        $this->load->model("User_model", "user");
        $this->load->model("Post_model", "post");
    }

    public function handle_index()
    {
        $posts = $this->post->getAdminPosts();
        $this->view('open_index.html', [
            "posts" => $posts
        ]);
    }

	public function handle_user($nickname=null)
	{
        $user = $this->user->get_user($nickname, "nickname");
        if(empty($user)) {
            show_404();
        }
        $posts = $this->post->getUserPosts($user["uid"]);
        $this->view('user_index.html', [
            "user" => $user,
            "posts" => $posts
        ]);
	}
}
