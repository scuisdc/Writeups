<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/23
 * Time: 上午1:54
 */
class User extends User_Controller
{
    function __construct()
    {
        User_Controller::__construct();
    }

    function init()
    {
        User_Controller::init();
        $this->load->model("Post_model", "post");
        $this->load->model("File_model", "file");
        $this->load->library('form_validation');

        $this->twig->addFunction('form_set_value', 'set_value');
        $this->twig->addFunction('form_validation_errors', 'validation_errors');
        $this->attachment_dir = $this->config->item("attachment_dir");
    }

    function before_handler()
    {
        User_Controller::before_handler();

        $post_count = $this->post->getUserPostCount();
        $file_count = $this->file->getUserFileCount();
        $this->template_data["post_count"] = $post_count;
        $this->template_data["file_count"] = $file_count;
    }

    public function handle_index()
    {
        $this->view("user_home.html");
    }

    public function handle_posts()
    {
        $posts = $this->post->getUserPosts();
        $this->view("user_posts.html", [
            "posts" => $posts
        ]);
    }

    public function handle_profile()
    {
        $this->load->model("User_model", "user");
        $this->twig->addFunction('form_open_multipart', 'form_open_multipart');
        if($this->input->method() == "post") {
            $nickname = I("post.nickname");
            $password = I("post.password");
            $motto = I("post.motto");

            $form_data = [
                "nickname" => $nickname
            ];
            $this->form_validation->set_data($form_data);
            if(!$this->form_validation->run('profile')) {
                $this->error(strip_tags(validation_errors()));
            }
            if(!$this->user->nickname_unique($nickname)) {
                $this->error("Nickname has been used");
            }
            $update = [
                "nickname" => $nickname,
                "motto" => $motto
            ];
            if(!empty($password)) {
                if($password != I('post.repassword')) {
                    $this->error("Confirm password error");
                }
                if(!$this->complex_password($password)) {
                    $this->error("Password must have at least one alpha and one number");
                }
                $update["password"] = $password;
            }
            if(!empty($_FILES["upfile"]["tmp_name"])) {
                $dir = $this->config->item("face_dir");
                $config = [];
                $config['upload_path'] = $dir;
                $config['allowed_types'] = 'gif|jpg|png';
                $config['file_name'] = strval($this->session->userinfo["uid"]);
                $config['max_size'] = 100;
                $config['file_ext_tolower'] = true;
                $config['overwrite'] = true;

                $this->load->library('upload', $config);
                if($this->upload->do_upload("upfile")) {
                    $update["face"] = $dir . $this->upload->data("file_name");
                } else {
                    $error = $this->upload->display_errors();
                    $this->error(strip_tags($error));
                }
            }

            $this->user->update_userinfo($update, $this->session->userinfo["uid"]);
            $this->update_session();
            redirect("user/profile");
        }
        $this->view("user_edit_info.html");
    }

    public function handle_file($fid=null)
    {
        error_reporting(0);
        $fid = intval($fid);
        if($fid > 0) {
            $file = $this->file->getFile($fid);
            if(empty($file)) {
                show_404();
            }
            $filepath = realpath($this->attachment_dir . '/' . $file->realname);
            $mime = $this->get_content_type($filepath);
            $this->output
                ->set_content_type($mime, "binary")
                ->set_output(file_get_contents($filepath));
        } else {
            show_404();
        }
    }

    public function handle_files()
    {
        $files = $this->file->getFiles();
        $this->view("user_files.html", [
            "files" => $files
        ]);
    }

    public function handle_upload()
    {
        $this->twig->addFunction('form_open_multipart', 'form_open_multipart');
        if($this->input->method() == "post") {
            $origin_filename = I("post.filename");
            $origin_filename = empty($origin_filename) ? $_FILES["upfile"]["name"] : $origin_filename;
            $filename = $this->get_unique_filename($origin_filename);

            $config = [];
            $config['upload_path'] = $this->attachment_dir;
            $config['allowed_types'] = 'gif|jpg|png|txt';
            $config['file_name'] = $filename;
            $config['max_size'] = 300;
            $config['file_ext_tolower'] = true;

            if(!$this->check_content("upfile")) {
                $error = "Illegal file content";
                $this->view("upload_file.html", ["error" => $error]);
            }
            $this->load->library('upload', $config);
            if($this->upload->do_upload("upfile")) {
                $this->file->addFile($origin_filename, $this->upload->data("file_name"));
                redirect("user/files");
            } else {
                $error = $this->upload->display_errors();
                $this->view("upload_file.html", ["error" => $error]);
            }
        } else {
            $this->view("upload_file.html");
        }
    }

    public function handle_write()
    {
        if($this->input->method() == "post") {
            $title = I("post.title");
            $content = I("post.content");
            $tags = I("post.tags");
            $form_data = [
                "title" => $title,
                "content" => $content
            ];
            $this->form_validation->set_data($form_data);
            if($this->form_validation->run('post')) {
                $content = htmlspecialchars($content);
                $parser = new \cebe\markdown\GithubMarkdown();
                $content = $parser->parse($content);
                $this->post->addPost($title, $content, $tags);
                redirect("user/posts");
            } else {
                $this->view("write_post.html");
            }
        } else {
            $this->view("write_post.html");
        }
    }

    public function handle_delete_post()
    {
        if($this->input->method() != "post") {
            redirect("user/posts");
        } else {
            $pids = I('post.posts/a', [], null, 'intval');
            $this->post->deletePost($pids);
            redirect("user/posts");
        }
    }

    public function handle_delete_file()
    {
        if($this->input->method() != "post") {
            redirect("user/files");
        } else {
            $fids = I('post.files/a', [], null, 'intval');
            $this->file->deleteFiles($fids);
            redirect("user/files");
        }
    }

    public function filter_content($content)
    {
        return true;
    }

    /*
     * defense sqli/xss inject
     */
    private function filter_filename($filename)
    {
        return preg_replace('/[^a-z0-9\-\_\.]/i', '_', $filename);
    }

    private function check_content($name)
    {
        if(isset($_FILES[$name]["tmp_name"])) {
            $content = file_get_contents($_FILES[$name]["tmp_name"]);
            if(strpos($content, "<?") === 0) {
                return false;
            }
        }
        return true;
    }

    /*
     * get unique filename
     */
    private function get_unique_filename($filename)
    {
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $name = pathinfo($filename, PATHINFO_FILENAME);
        return $this->filter_filename($name . '_' . random_string('alnum', 16) . '.' . $ext);
    }

    private function get_content_type($filename)
    {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        return $finfo->file($filename);
    }

}