<?php

/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/30
 * Time: 上午11:53
 */
class Post extends Public_Controller
{
    function init()
    {
        Public_Controller::init();
        $this->load->model("User_model", "user");
        $this->load->model("Post_model", "post");
    }

    public function handle_index($pid=0)
    {
        $pid = intval($pid);
        $post = $this->post->getPost($pid);
        if(empty($post)) {
            show_404();
        } else {
            $this->view('show_post.html', [
                "post" => $post
            ]);
        }
    }

    public function handle_search()
    {
        $keyword = I("post.keyword/s");
        $posts = $this->post->searchPosts($keyword);
        $this->view('post_list.html', [
            "posts" => $posts
        ]);
    }
}