<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/22
 * Time: 下午4:03
 */
if ( ! function_exists('I')) {

    function I($name, $default="", $rex=null, $filters=null, $xss_filter=false)
    {
        $self = &get_instance();
        $check_rex = function(&$value, $rex)
        {
            $walk = function(&$value, $key, $rex)
            {
                $value = preg_match($rex, $value) ? $value : null;
            };
            if(is_array($value)) {
                array_walk_recursive($value, $walk, $rex);
            } else {
                $value = preg_match($rex, $value) ? strval($value) : null;
            }
        };

        $filters = empty($filters) ? $self->config->item('global_filter_functions') : $filters;
        $filter_arr = explode('|', $filters);
        $walk_filter_function = function(&$data, $filter_arr)
        {
            $callback = function(&$value, $key, $filter_function)
            {
                $value = call_user_func($filter_function, $value);
            };
            foreach($filter_arr as $filter_function) {
                if (is_array($data)) {
                    array_walk_recursive($data, $callback, $filter_function);
                } else {
                    $data = call_user_func($filter_function, $data);
                }
            }
        };

        if (strpos($name, '/')) {
            list($name, $type) = explode('/', $name, 2);
        } else {
            $type = 's';
        }

        if (strpos($name, '.')) {
            list($method, $name) = explode('.', $name, 2);
        } else {
            $method = 'param';
        }

        switch (strtolower($method)) {
            case 'get':
                $input = $self->input->get($name, $xss_filter);
                break;
            case 'post':
                $input = $self->input->post($name, $xss_filter);
                break;
            case 'cookie':
                $input = $self->input->cookie($name, $xss_filter);
                break;
            case 'server':
                $input = $self->input->server($name, $xss_filter);
                break;
            case 'request':
                $input = $self->input->get_post($name, $xss_filter);
                break;
            case 'param':
            default:
                switch ($self->input->method()) {
                    case 'post':
                        $input = $self->input->post($name, $xss_filter);
                        break;
                    default:
                        $input = $self->input->get($name, $xss_filter);
                }
                break;
        }

        if (empty($input)) {
            return $default;
        }

        switch ($type) {
            case 's':
                $input = is_scalar($input) ? strval($input) : "";
                !empty($rex) && $check_rex($input, $rex);

                break;
            case 'a':
                $input = is_array($input) ? $input : [];
                !empty($rex) && $check_rex($input, $rex);
                break;
            case 'i':
                $input = intval($input);
                break;
            case 'f':
                $input = floatval($input);
                break;
            case 'b':
                $input = (boolean)$input;
        }

        if(is_array($input) || is_string($input)) {
            $walk_filter_function($input, $filter_arr);
        }
        return $input;
    }
}