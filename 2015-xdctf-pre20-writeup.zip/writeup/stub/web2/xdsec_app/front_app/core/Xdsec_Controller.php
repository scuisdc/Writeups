<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/22
 * Time: 上午1:48
 */
class Base_Controller extends CI_Controller
{
    public $template_data = [];

    public function init()
    {
        $this->twig->addFunction("get_user_avatar", [$this, "get_user_avatar"]);
    }

    protected function view($template_name, $data = [])
    {
        $data = array_merge($this->template_data, $data);
        $this->twig->render($template_name, $data);
    }

    protected function success($message, $jump=null)
    {
        $jump = empty($jump) ? site_url() : $jump;
        $this->view("error.html", [
            "error_title" => "Congratulation, success!",
            "error_msg" => $message,
            "jump" => $jump
        ]);
        exit;
    }

    protected function error($error_msg, $jump="javascript:history.back(-1);", $status_code=200)
    {
        $this->output->set_status_header($status_code);
        $this->view("error.html", [
            "error_title" => "Oops, you have an error!",
            "error_msg" => $error_msg,
            "jump" => $jump
        ]);
        exit;
    }

    public function is_user()
    {
        return !empty($_SESSION['userinfo']) &&
        is_array($this->session->userinfo) &&
        $this->session->userinfo["uid"] > 0;
    }

    public function _remap($method, $params=[])
    {
        $method = "handle_{$method}";
        if (method_exists($this, $method)) {
            if(method_exists($this, "before_handler")) {
                call_user_func([$this, "before_handler"]);
            }
            $ret = call_user_func_array([$this, $method], $params);
            if(method_exists($this, "after_handler")) {
                call_user_func([$this, "after_handler"]);
            }
            return $ret;
        } else {
            show_404();
        }
    }

    public function complex_password($password)
    {
        if(!preg_match('/[a-z]/i', $password)) {
            $this->form_validation->set_message('complex_password', 'The {field} must have alpha');
            return false;
        } elseif(!preg_match('/[0-9]/', $password)) {
            $this->form_validation->set_message('complex_password', 'The {field} must have number');
            return false;
        } else {
            return true;
        }
    }

    public function get_user_avatar($uid=null)
    {
        if($this->is_user() && isset($_SESSION["userinfo"]["face"])) {
            $url = base_url($this->session->userinfo["face"]);
        } elseif($uid > 0) {
            $this->load->model("User_model", "user");
            $user = $this->user->get_user($uid);
            if($user && isset($user["face"])) {
                $url = base_url($user["face"]);
            } else {
                $url = base_url("img/default_face.jpg");
            }
        } else {
            $url = base_url("img/default_face.jpg");
        }
        return $url;
    }

    public function update_session()
    {
        if($this->is_user()) {
            $user = $this->user->get_user($this->session->userinfo["uid"]);
            unset($user["password"]);
            $this->session->userinfo = $user;
        }
    }
}

class Public_Controller extends Base_Controller
{

}

class User_Controller extends Base_Controller
{
    public function before_handler()
    {
        if(!$this->is_user()) {
            redirect("auth/login");
        }
    }
}