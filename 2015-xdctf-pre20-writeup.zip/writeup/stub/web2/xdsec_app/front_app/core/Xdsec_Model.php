<?php

/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/24
 * Time: 下午6:47
 */
class Xdsec_Model extends CI_Model
{
    protected function filter_number(&$arr)
    {
        $arr = array_filter($arr, function($value){
            return is_int($value);
        });
    }
}