<?php

/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/29
 * Time: 下午6:52
 */
class Log extends Base_Controller
{
    protected $default_log = [];
    public function init()
    {
        $ip = I("post.ip/s") ? I("post.ip/s") : $this->input->ip_address();
        $this->default_log = $this->query_log($ip);
        $this->ip_address = $ip;
    }

    protected function query_log($value, $key="ip")
    {
        $user_table = $this->db->dbprefix("admin");
        $log_table = $this->db->dbprefix("adminlog");
        switch($key) {
            case "ip":
            case "time":
            case "log":
                $table = $log_table;
                break;
            case "username":
            case "aid":
            default:
                $table = $user_table;
                break;
        }
        $query = $this->db->query("SELECT `{$user_table}`.`username`, `{$log_table}`.*
                                    FROM `{$user_table}`, `{$log_table}`
                                    WHERE `{$table}`.`{$key}`='{$value}'
                                    ORDER BY `{$log_table}`.`time` DESC
                                    LIMIT 20");
        if($query) {
            $ret = $query->result();
        } else {
            $ret = [];
        }
        return $ret;
    }

    public function handle_index($ip=null)
    {
        if($ip) {
            $this->default_log = $this->query_log($ip);
        }
        $this->view("log.html", [
            "logs" => $this->default_log,
            "owner" => $this->ip_address
        ]);
    }

    public function handle_name($username=null)
    {
        $this->view("log.html", [
            "logs" => $this->query_log($username, "username"),
            "owner" => $username
        ]);
    }
}