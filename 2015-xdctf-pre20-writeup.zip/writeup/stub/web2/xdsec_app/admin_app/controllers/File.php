<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/28
 * Time: 下午6:21
 * File Manager
 */
class File extends Base_Controller
{
    protected $default_dir;
    protected $base_dir;
    protected $allow_ext;
    public function init()
    {
        Base_Controller::init();
        $this->default_dir = "css";
        $this->base_dir = realpath("./") . "/";
        $this->allow_ext = [
            "css" => ["css"],
            "img" => ["png", "gif", "jpg"],
            "js" => ["js", "map"],
            "fonts" => ["eot", "svg", "ttf", "woff", "woff2", "txt"]
        ];
        $this->load->helper('file');
        $this->template_data["default_dir"] = $this->default_dir;
    }

    protected function check_extension($filename, $dir)
    {
        if(isset($this->allow_ext[$dir])) {
            $allow_ext = $this->allow_ext[$dir];
        } else {
            $allow_ext = $this->allow_ext[$this->default_dir];
        }
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        return in_array($ext, $allow_ext);
    }

    protected function check_mime_type($oldname, $newname)
    {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $old_type = finfo_file($finfo, $oldname);
        $mimes = & get_mimes();
        $new_file_ext = strtolower(substr(strrchr($newname, '.'), 1));
        $new_type = isset($mimes[$new_file_ext]) ? $mimes[$new_file_ext] : [];
        if(is_string($mimes[$new_file_ext])) {
            $new_type = [$mimes[$new_file_ext]];
        } elseif (isset($mimes[$new_file_ext])) {
            $new_type = (array)$new_type;
        } else {
            $new_type = [];
        }
        return in_array($old_type, $new_type);

    }

    protected function check_exists($filename)
    {
        return file_exists($filename);
    }

    protected function get_files($directory)
    {
        $files = [];
        $resource = opendir($directory);
        while (false !== ($file = readdir($resource))) {
            array_push($files, $file);
        }
        return $files;
    }

    protected function json_output($object, $msg="")
    {
        if($object === false) {
            $object = ["success" => false, "error" => $msg];
        }
        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($object))
            ->_display();
        exit;
    }

    public function handle_index()
    {
        $dir = $this->base_dir . $this->default_dir . "/";
        $paths = $this->get_files($dir);
        $paths = array_filter($paths, function($val)
        {
            return $val != "." && $val != "..";
        });
        array_walk($paths, function(&$filename, $key)
        {
            $filename = htmlspecialchars($filename, ENT_COMPAT | ENT_HTML401 | ENT_QUOTES);
        });
        $this->view("file.html", [
            "paths" => $paths
        ]);
    }

    public function handle_list()
    {
        $dir = I("post.dir/s", $this->default_dir, '/^(css|img|fonts|js)$/');
        if(empty($dir)) {
            $this->json_output(false, "Illegal directory name");
        }
        $list_dir = $this->base_dir . $dir;
        $paths = $this->get_files($list_dir);
        $allow_ext = $this->allow_ext[$dir];
        $callback = function($filename) use($allow_ext) {
            $ext = pathinfo($filename, PATHINFO_EXTENSION);
            return in_array($ext, $allow_ext);
        };
        $paths = array_values(array_filter($paths, $callback));
        $this->json_output($paths);
    }

    public function handle_info()
    {
        $dir = I("post.dir/s", $this->default_dir, '/^(css|img|fonts|js)$/');
        if(empty($dir)) {
            $this->json_output(false, "Illegal directory name");
        }
        $file = I("post.filename/s");
        $filename = realpath($dir . "/" . $file);
        if(!$this->check_extension($filename, $dir)) {
            $this->json_output(false, "File doesn't exists or illegal file extension");
        }
        $attrs = get_file_info($filename,
            ['name', 'size', 'date', 'readable', 'writeable', 'executable', 'fileperms']);
        $this->json_output($attrs);
    }

    public function handle_delete()
    {
        $dir = I("post.dir/s", $this->default_dir, '/^(css|img|fonts|js)$/');
        if(empty($dir)) {
            $this->json_output(false, "Illegal directory name");
        }
        $file = I("post.filename/s");
        $filename = realpath($dir . "/" . $file);
        if(!$this->check_extension($filename, $dir)) {
            $this->json_output(false, "File doesn't exists or illegal file extension");
        }
        $success = @unlink($filename);
        if($success) {
            $success = ["success" => true];
        } else {
            $success = ["success" => false, "error" => "Operation not permitted"];
        }
        $this->assign_log("Delete filename");
        $this->json_output($success);
    }

    public function handle_rename()
    {
        $dir = I("post.dir/s", $this->default_dir, '/^(css|img|fonts|js)$/');
        if(empty($dir)) {
            $this->json_output(false, "Illegal directory name");
        }
        $file = I("post.filename/s");
        $filename = realpath($dir . "/" . $file);
        if(!$this->check_extension($filename, $dir)) {
            $this->json_output(false, "File doesn't exists or illegal file extension");
        }
        $new_name = I("post.newname/s", "", "/^[a-zA-Z0-9 _\-]+\.(?!((php|phtml|php3|html|htm)$))[a-zA-Z0-9 _\-]+$/");
        $new_name = dirname($filename) . "/" . basename($new_name);

        if(!$this->check_mime_type($filename, $new_name)) {
            $this->json_output(false, "mime type is not equal");
        }
        $ret = @rename($filename, $new_name);
        $this->assign_log("Rename filename");
        $this->json_output($ret);
    }

    public function handle_download()
    {
        $dir = I("post.dir/s", $this->default_dir, '/^(css|img|fonts|js)$/');
        if(empty($dir)) {
            $this->json_output(false, "Illegal directory name");
        }
        $url = I("post.url/s", "", "#^http://libs\.useso\.com/[a-z0-9\.\-_ \/]+\.(js|css|map|gif|jpg|png)$#is");
        if(empty($url)) {
            $this->json_output(false, "Bad url");
        }
        $opts = ['http' =>
            [
                'method'  => 'GET',
                'header'  => "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) ".
                             "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36\r\n".
                             "Accept-Encoding: gzip\r\n",
                'timeout' => 60
            ]
        ];
        $context  = stream_context_create($opts);
        $result = file_get_contents($url, false, $context);
        $data = gzdecode($result);

        $tmp_arr = explode('.', $url);
        $ext = end($tmp_arr);
        if(!in_array($ext, $this->allow_ext[$dir])) {
            $this->json_output(false, "iLLegal extension");
        }
        $path = $dir . "/" . basename($url);
        $ret = file_put_contents($path, $data);
        $this->assign_log("Download file");
        $this->json_output($ret ? ["success" => true] : false);
    }

    public function assign_log($log)
    {
        if($this->input->method() == "post") {
            $ip = $this->input->ip_address();
            $data = [
                "log" => $log,
                "ip" => $ip,
                "aid" => $this->session->admin["aid"]
            ];
            $this->db->insert("adminlog", $data);
        }
    }
}