<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/25
 * Time: 上午2:02
 */
class Auth extends Base_Controller
{

    /*
     * log login ip address
     */
    protected function update_log_ipaddress()
    {
        $aid = $this->session->admin["aid"];
        if(intval($aid)) {
            $ip = $this->input->ip_address();
            $this->db->where("`aid`='{$aid}'")->set("ip", $ip)->update("admin");
            $data = [
                "log" => "admin login",
                "ip" => $ip,
                "aid" => $aid
            ];
            $this->db->insert("adminlog", $data);
        }
    }

    public function handle_login()
    {
        if($this->input->method() == "post") {
            $username = I("post.username/s");
            $password = I("post.password/s", "", null, "md5");
            $admin = $this->db->where("`username`='{$username}' && `password`='{$password}'")->get("admin")->row_array();
            if(empty($admin)) {
                $this->session->admin = [];
                $this->error("Password error!!");
            } else {
                $this->session->admin = $admin;
                $this->update_log_ipaddress();
                redirect("admin");
            }
        } else {
            $this->view("login.html");
        }
    }

    public function handle_logout()
    {
        unset($_SESSION["admin"]);
        redirect("auth/login");
    }
}