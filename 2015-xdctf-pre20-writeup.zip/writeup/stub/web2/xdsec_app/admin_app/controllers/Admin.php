<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends Base_Controller
{
	public function handle_index()
	{
        $logs = $this->db
            ->where("`aid`='{$this->session->admin['aid']}'")
            ->order_by("time", "desc")
            ->limit(20)
            ->get("adminlog")
            ->result();
        $this->view("index.html", [
            "logs" => $logs
        ]);
	}
}
