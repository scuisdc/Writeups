<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Hooks
| -------------------------------------------------------------------------
| This file lets you define "hooks" to extend CI without hacking the core
| files.  Please see the user guide for info:
|
|	http://codeigniter.com/user_guide/general/hooks.html
|
*/

$hook['post_controller_constructor'] = function()
{
    $self = & get_instance();
    $self->load->library('session');
    if(SELF == "admin.php" || config_item("index_page") == "admin.php") {
        $self->error("Please rename admin filename 'admin.php' and config item 'index_page'", site_url());
    }
    $self->template_data["is_admin"] = $self->is_admin();
    if(method_exists($self, "init")) {
        call_user_func([$self, "init"]);
    }
};

$hook['post_controller'] = function()
{
    session_write_close();
};