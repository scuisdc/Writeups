<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Xdsec_Input extends CI_Input
{
    function ip_address()
    {
        if (isset($_SERVER["HTTP_CLIENT_IP"])) {
            $ip = $_SERVER["HTTP_CLIENT_IP"];
        } elseif (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) {
            $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
        } elseif (isset($_SERVER["REMOTE_ADDR"])) {
            $ip = $_SERVER["REMOTE_ADDR"];
        } else {
            $ip = CI_Input::ip_address();
        }
        if(!preg_match("/(\d+)\.(\d+)\.(\d+)\.(\d+)/", $ip))
            $ip = "127.0.0.1";
        return trim($ip);
    }
}