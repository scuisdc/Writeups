<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Created by PhpStorm.
 * User: phithon
 * Date: 15/9/22
 * Time: 上午1:48
 */
class Base_Controller extends CI_Controller
{
    public $template_data = [];

    /*
     * Do parameters initial
     */
    public function init()
    {

    }

    protected function view($template_name, $data = [])
    {
        $data = array_merge($this->template_data, $data);
        $this->twig->render($template_name, $data);
    }

    public function success($message, $jump=null)
    {
        $jump = empty($jump) ? site_url() : $jump;
        $this->view("error.html", [
            "error_title" => "Congratulation, success!",
            "error_msg" => $message,
            "jump" => $jump
        ]);
        exit;
    }

    public function error($error_msg, $jump="javascript:history.back(-1);", $status_code=200)
    {
        $this->output->set_status_header($status_code);
        $this->view("error.html", [
            "error_title" => "Oops, you have an error!",
            "error_msg" => $error_msg,
            "jump" => $jump
        ]);
        exit;
    }

    public function is_admin()
    {
        return !empty($_SESSION['admin']) &&
            is_array($this->session->admin) &&
            $this->session->admin["aid"] > 0;
    }

    public function _remap($method, $params=[])
    {
        $method = "handle_{$method}";
        if (method_exists($this, $method)) {
            if(method_exists($this, "before_handler")) {
                call_user_func([$this, "before_handler"]);
            }
            $ret = call_user_func_array([$this, $method], $params);
            if(method_exists($this, "after_handler")) {
                call_user_func([$this, "after_handler"]);
            }
            return $ret;
        } else {
            show_404();
        }
    }

    public function update_session()
    {

    }

    public function before_handler()
    {
        if($this->router->class != "auth") {
            if(!$this->is_admin()) {
                redirect("auth/login");
            } else {
                $this->template_data["admin"] = $this->session->admin;
            }
        }
    }
}