// Empty JS for your own code to be here
(function(){
    var check = false;
    $("#checkall").on("click", function(){
        $("#checkbox_list input:checkbox").prop("checked", !check);
        check = !check;
    });
})();