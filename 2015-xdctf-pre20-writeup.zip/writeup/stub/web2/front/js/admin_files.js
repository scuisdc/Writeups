function htmlspecialchars(str)
{
    if(typeof str == "string") {
        return str
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/'/g, "&#039;")
            .replace(/"/g, "&quot;");
    } else {
        return str;
    }
}

function info(filename) {
    var directory = $("#sort").val();
    $.ajax({
        url: info_dir,
        type: "post",
        dataType: "json",
        data: {
            dir: directory,
            filename: filename
        },
        success: function (data) {
            html = "";
            for(var i in data) {
                html += i + " : " + htmlspecialchars(data[i]) + "<br/>";
            }
            $("#file-info").html(html);
        }
    });
    return false;
}

function list(directory) {
    directory = directory || $("#sort").val();
    $.ajax({
        url: list_dir,
        type: "post",
        dataType: "json",
        data: {
            dir: directory
        },
        success: function (data) {
            html = "";
            for(var filename in data) {
                var name = htmlspecialchars(data[filename]);
                var link_str = '<a href="javascript:info(\''+name+'\');">Info</a> ' +
                    '<a href="javascript:del(\''+name+'\');">Delete</a> '+
                    '<a href="javascript:rename(\''+name+'\')">Rename</a>';
                html += "<tr><td><a href=\"/"+directory+"/"+name+"\" target=\"_blank\">" + name
                    + "</a></td><td class=\"text-right\">" + link_str + "</td></tr>";
            }
            $("#dir-body").html(html);
        }
    });
}

function del(filename) {
    var directory = $("#sort").val();
    $.ajax({
        url: delete_dir,
        type: "post",
        dataType: "json",
        data: {
            dir: directory,
            filename: filename
        },
        success: function (data) {
            if (data.success) {
                list(directory);
            } else {
                alert(data.error);
            }
        }
    });
    return false;
}

function rename(filename) {
    var directory = $("#sort").val();
    var new_name;
    if((new_name = prompt("Please input new name"))) {
        if(!/^[a-zA-Z0-9 _\-]+\.(?!((php|phtml|php3|html|htm)$))[a-zA-Z0-9 _\-]+$/i.test(new_name)) {
            alert("File extension cant't be php/phtml/php3/html/htm");
            return false;
        }
    } else {
        return false;
    }
    $.ajax({
        url: rename_dir,
        type: "post",
        dataType: "json",
        data: {
            dir: directory,
            filename: filename,
            newname: new_name
        },
        success: function (data) {
            list(directory);
        }
    });
    return false;
}

function download(url)
{
    var directory = $("#sort").val();
    $.ajax({
        url: download_dir,
        type: "post",
        dataType: "json",
        data: {
            dir: directory,
            url: url
        },
        success: function (data) {
            if(data.success) {
                list(directory);
            } else {
                alert(data.error);
            }
        }
    });
    return false;
}

$(document).on("ready", function(){
    $("#sort").on("change", function (e) {
        var directory = e.target.value;
        list(directory);
        return false;
    });
});