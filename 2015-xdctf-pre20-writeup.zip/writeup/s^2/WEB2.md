# WEB2-200

`.git` 目录可以访问。用 GitTools 的 Dumper 工具直接下载整个 repo，`index.php` 里可见 flag。

